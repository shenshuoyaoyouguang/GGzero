#!/bin/bash

# You must have run `go build main.go` prior to running this

export GIN_MODE=release
./main
